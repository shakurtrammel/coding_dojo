from django.urls import path
from users_app import views


urlpatterns = [
    path("process-form", views.processForm, name="process-form"),
    path("", views.index, name="index"),
]
