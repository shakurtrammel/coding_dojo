from django.urls import path
from td_app import views


urlpatterns = [
    path("", views.index),
]