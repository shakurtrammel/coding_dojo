from django.apps import AppConfig


class TdAppConfig(AppConfig):
    name = 'td_app'
