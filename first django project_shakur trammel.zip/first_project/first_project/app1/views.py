from django.shortcuts import HttpResponse, redirect, render

# Create your views here.
def index(request):
    return HttpResponse('Placeholder to later display a list of all blogs')

def new(request):
    return HttpResponse('Placeholder to display a new form to create a new blog')

def show(request, number):
    return HttpResponse('Placeholder to display blog number: ' + str(number))

def edit(request, number):
    return HttpResponse('Placeholder to edit blog ' + str(number))

def destroy(request, number):
    return redirect("/")

def create(request, url):
    return redirect("/")
