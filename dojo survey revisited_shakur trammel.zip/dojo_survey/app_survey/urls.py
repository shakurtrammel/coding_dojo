from django.urls import path
from app_survey import views


urlpatterns = [
    path("", views.index),
    path("process_form", views.process_form),
    path("result", views.result),
    path('<url>', views.catch_all),
]
