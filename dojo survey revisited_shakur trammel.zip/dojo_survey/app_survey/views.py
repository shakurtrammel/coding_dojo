from django.shortcuts import redirect, render

# Create your views here.
def index(request):
    return render(request, "index.html")

def process_form(request):
    if request.method == 'POST':
        print(request.POST)
    request.session['name']      =  request.POST['name']
    request.session['location']  =  request.POST['location']
    request.session['language']  =  request.POST['language']
    request.session['comment']   =  request.POST['comment']
    return redirect("/result")

def result(request):
    print('Got here from process_form() redirect')
    return render(request, "result.html")

def catch_all(request, url):
    return redirect("/")
