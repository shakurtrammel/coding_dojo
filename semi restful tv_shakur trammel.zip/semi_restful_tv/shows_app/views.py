from django.shortcuts import redirect, render
from django.contrib import messages
from .models import Show


def index(request):
    return redirect("shows")


def shows(request):
    context = {
        "all_shows": Show.objects.all()
    }
    return render(request, "shows.html", context)


def new(request):
    return render(request, "new.html")


def create(request):
    errors = Show.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/shows/new")
    else:
        Show.objects.create(
            title=request.POST['title'],
            network=request.POST['network'],
            release_date=request.POST['release-date'],
            desc=request.POST['desc']
        )
    new_show = Show.objects.last()
    new_show_id = new_show.id
    return redirect(f"/shows/{ new_show_id }")


def read(request, requested_show_id):
    context = {
        "one_show": Show.objects.get(id=requested_show_id),
    }
    return render(request, "read.html", context)


def edit(request, requested_show_id):
    show = Show.objects.get(id=requested_show_id)
    date = show.release_date
    formatted_date = date.strftime("%Y-%m-%d")
    context = {
        "show": Show.objects.get(id=requested_show_id),
        "show_fdate": formatted_date,
    }
    return render(request, "edit.html", context)


def update(request, requested_show_id):
    errors = Show.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/shows/{requested_show_id}/edit")
    else:
        show_to_update = Show.objects.get(id=requested_show_id)
        show_to_update.title = request.POST['title']
        show_to_update.network = request.POST['network']
        show_to_update.release_date = request.POST['release-date']
        show_to_update.desc = request.POST['desc']
        show_to_update.save()
    return redirect(f"/shows/{ requested_show_id }")


def destroy(request, requested_show_id):
    show_to_remove = Show.objects.get(id=requested_show_id)
    show_to_remove.delete()
    return redirect("shows")
