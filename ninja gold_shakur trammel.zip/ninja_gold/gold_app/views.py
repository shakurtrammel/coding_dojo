from django.shortcuts import redirect, render
from gold_app.custom import addGold, takeGold
import random


# Views
def index(request):
    return render(request, "index.html")

     
def processMoney(request):
    request_keys = list(dict.keys(request.POST))
    location = request_keys[1]
    if location == "farm":
        addGold(request, location, 10, 20)
    elif location == "cave":
        addGold(request, location, 5, 10)
    elif location == "house":
        addGold(request, location, 2, 5)
    elif location == "casino":
        random_sign = random.uniform(-1,1)
        if random_sign > 0:
            addGold(request, location, 0, 50)
        elif random_sign < 0:
            takeGold(request, location, 0, 50)
    return redirect("/")
    
