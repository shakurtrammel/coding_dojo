from django.urls import path
from gold_app import views


urlpatterns = [
    path("process-money", views.processMoney, name="process"),
    path("", views.index, name="index")
]
