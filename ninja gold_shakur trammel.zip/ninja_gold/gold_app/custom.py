import random
import datetime
 


def addGold(request, location, min, max):
    gold = random.randint(min, max)
    timestamp = datetime.datetime.now().strftime("%B %d, %Y %I:%M %p")
    message = f"Earned {gold} golds from the {location}! ({timestamp})"
    request.session['message'] = message


def takeGold(request, location, min, max):
    gold = random.randint(min, max)
    timestamp = datetime.datetime.now().strftime("%B %d, %Y %I:%M %p")
    message = f"Entered a {location} and lost {gold} golds...ouch..({timestamp})"
    request.session['message'] = message