from django.shortcuts import HttpResponse, redirect, render
from django.contrib import messages
import bcrypt
from .models import User


def index(request):
    return render(request, "index.html")


def register(request):
    errors = User.objects.form_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        password_hash = bcrypt.hashpw(request.POST['rpassword'].encode(), bcrypt.gensalt()).decode()
        print(password_hash)
        User.objects.create(
            fname=request.POST['fname'],
            lname=request.POST['lname'],
            email=request.POST['email'],
            password=password_hash,
        )
    return redirect("/success")


def login(request):
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        user = User.objects.filter(email=request.POST["lemail"])
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(request.POST["lpassword"].encode(), logged_user.password.encode()):
                print("Password match")
                request.session["userid"] = logged_user.id
                return redirect("/success")
            else:
                print("Failed password")
    return redirect("/")

def success(request):
    try:
        user = User.objects.get(id=request.session["userid"])
        context = {
            "user_name": user.fname,
        }
    except:
        return HttpResponse("Must be logged in to access this page.")
    else:
        return render(request, "success.html", context)


def logout(request):
    request.session.flush()
    return redirect("/")

