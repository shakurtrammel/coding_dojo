from django.urls import path
from login_app import views


urlpatterns = [
    path("logout", views.logout, name="logout"),
    path("login", views.login, name="login"),
    path("register", views.register, name="register"),
    path("success", views.success, name="success"),
    path("", views.index, name="index"),
]
