from django.db import models
import re
import bcrypt


class UserManager(models.Manager):
    def form_validator(self, data):
        errors = {}
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if (len(data["fname"]) < 2) or (not data["fname"].isalpha()):
            errors["fname"] = "First Name should be at least 2 characters and contain only letters."
        if (len(data["lname"]) < 2) or (not data["lname"].isalpha()):
            errors["lname"] = "Last Name should be at least 2 characters and contain only letters."
        if not EMAIL_REGEX.match(data["email"]):             
            errors["email"] = "Invalid email address."
        if len(data["rpassword"]) < 8:
            errors["rpassword"] = "Password should be at least 8 characters."
        elif data["conf_pass"] != data["rpassword"]:
            errors["conf_pass"] = "Passwords do not match."
        return errors

    def login_validator(self, data):
        errors = {}
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(data["lemail"]):             
            errors["lemail"] = "Invalid email address."
        else:
            if len(data["lpassword"]) == 0:
                errors["lpassword"] = "Password is required."
            elif len(data["lpassword"]) < 8:
                errors["lpassword"] = "Password should be at least 8 characters."
        return errors


class User(models.Model):
    fname = models.CharField(max_length=255)
    lname = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
