from django.shortcuts import redirect, render

# Create your views here.
def index(request):
    return render(request, "index.html")

def result(request):
    if request.method == 'POST':
        print(request.POST)
    context = {
        'name': request.POST['name'],
        'location': request.POST['location'],
        'language': request.POST['language'],
        'comment': request.POST['comment'],
    }
    return render(request, "result.html", context)

def catch_all(request, url):
    return redirect("/")
