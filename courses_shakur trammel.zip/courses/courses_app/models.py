from django.db import models


class CourseManager(models.Manager):
    def form_validator(self, data):
        errors = {}
        if len(data['name']) < 5:
            errors["name"] = "Name should be at least 5 characters."
        if len(data['desc']) < 15:
            errors["desc"] = "Description should be at least 15 characters."
        return errors


class Course(models.Model):
    name = models.CharField(max_length=255)
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = CourseManager()
