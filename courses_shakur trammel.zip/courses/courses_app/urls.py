from django.urls import path
from courses_app import views


urlpatterns = [
    path("delete/<int:id>", views.delete, name="delete"),
    path("remove/<int:id>", views.remove, name="remove"),
    path("remove", views.remove, name="remove"),
    path("add", views.add, name="add"),
    path("", views.index, name="index"),
]
