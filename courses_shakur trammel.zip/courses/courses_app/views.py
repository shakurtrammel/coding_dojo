from django.shortcuts import redirect, render
from django.contrib import messages
from .models import Course


def index(request):
    context = {
        "courses": Course.objects.all()
    }
    return render(request, "add.html", context)


def add(request):
    errors = Course.objects.form_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        Course.objects.create(
            name=request.POST['name'],
            desc=request.POST['desc']
        )
    return redirect("/")


def delete(request, id):
    course = Course.objects.get(id=id)
    course.delete()
    return redirect("/")


def remove(request, id):
    context = {
        "course": Course.objects.get(id=id)
    }
    return render(request, "remove.html", context)
