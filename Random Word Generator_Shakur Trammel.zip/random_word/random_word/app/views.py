from django.shortcuts import redirect, render
from django.utils.crypto import get_random_string
from .custom import increment_by_1, reset_counter

# Create your views here.

def index(request):
    request.session['attempts'] = reset_counter()
    request.session['word'] = "Click Generate!"
    return render(request, "index.html")


def random_word(request):
    if request.method == 'GET':
        random_string = get_random_string(length=14)
        request.session['word'] = random_string
        request.session['attempts'] = increment_by_1()
    return render(request, "index.html")


def reset(request):
    request.session['attempts'] = reset_counter()
    return redirect("/random_word")


def catch_all(request, url):
    return redirect("/")