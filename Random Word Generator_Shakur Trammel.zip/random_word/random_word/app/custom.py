
x = 0

def increment_by_1():
    global x
    x += 1
    print('adding 1')
    return x

def reset_counter():
    global x
    x = 0
    return x